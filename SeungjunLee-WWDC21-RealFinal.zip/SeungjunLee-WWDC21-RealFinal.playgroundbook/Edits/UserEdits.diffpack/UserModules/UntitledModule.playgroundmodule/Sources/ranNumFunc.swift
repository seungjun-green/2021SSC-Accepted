
import PlaygroundSupport
import SwiftUI




func ran1() -> Double {
    let randomInt = Int.random(in: 150..<245)
    let a = Double(randomInt)
    let b = a / Double(255)
    let c = Double(b)
    
    
    
    
    return c
    
}

func ran2() -> Double {
    let randomInt = Int.random(in: 150..<245)
    let a = Double(randomInt)
    let b = a / Double(255)
    let c = Double(b)
    // colorA1.append(c)
    
    
    return c
    
}


func ran3() -> Double {
    let randomInt = Int.random(in: 150..<245)
    let a = Double(randomInt)
    let b = a / Double(255)
    let c = Double(b)
    // colorA1.append(c)
    
    
    return c
    
}
